from art import logo, vs
from game_data import data
import random
from replit import clear
print(logo)
score = 0


def format_data(account):
  account_name = account["name"]
  account_description = account["description"]
  account_country = account["country"]

  return f"{account_name} , a {account_description} , from {account_country}"

def check_answer(guess,a_follower_count,b_follower_count):
  if a_follower_count > b_follower_count:
    return guess == "a"
  else:
    return guess == "b"

game_continue = True
account_b = random.choice(data)


while game_continue:
  account_a = account_b
  account_b = random.choice(data)
  
  while account_a == account_b:
    account_b = random.choice(data)
  
  print(f"Compare A : {format_data(account_a)}.")
  print(vs)
  print(f"Compare B : {format_data(account_b)}.")
  
  
  guess = input("Who has more followers? Typw 'A' or 'B':").lower()
  
  
  a_follower_count = account_a["follower_count"]
  b_follower_count = account_b["follower_count"]
  is_correct = check_answer(guess, a_follower_count, b_follower_count)
  
  clear()
  print(logo)
  if is_correct:
    score += 1
    print(f"You are correct! Current score {score}.")
    
  else:
    game_continue = False
    print(f"You are wrong, Final score {score}.")



# def get_data():
#   choose = random.choice(data)
#   return choose

# def Calculation(Input_Value):
#   point = 0
#   if Input_Value == "A":
#     if ch_follower_count1 >= ch_follower_count2:
#       return point + 1
#     else:
#       return point
#   else:
#     if ch_follower_count1 <= ch_follower_count2:
#       return point + 1
#     else:
#       return point

# Condition = True

# while Condition:
#   New_pickup1 = get_data()
  
#   ch_name1 = New_pickup1["name"]
#   ch_follower_count1 = New_pickup1["follower_count"]
#   ch_description1 = New_pickup1["description"]
#   ch_country1 = New_pickup1["country"]
  
#   print(
#     f"Compare A : {ch_name1} , a {ch_description1} , from {ch_country1} , count = {ch_follower_count1}")
  
#   New_pickup2 = get_data()
  
#   ch_name2 = New_pickup2["name"]
#   ch_follower_count2 = New_pickup2["follower_count"]
#   ch_description2 = New_pickup2["description"]
#   ch_country2 = New_pickup2["country"]
  
#   print(
#     f"Compare B : {ch_name2} , a {ch_description2} , from {ch_country2} , count = {ch_follower_count2}")
  
#   Input_Value = input("Who has more followers? Typw 'A' or 'B':")
  
#   point = 0
#   if Input_Value == "A":
#     if ch_follower_count1 >= ch_follower_count2:
#       return True
#     else:
#       return point
#   else:
#     if ch_follower_count1 <= ch_follower_count2:
#       return point + 1
#     else:
#       return point



# Value = Calculation(Input_Value)
